package com.example.calc;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SecondActivity extends AppCompatActivity {
    private TextView textView;
    int c = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);

        textView = findViewById(R.id.textView);

        Intent intent = getIntent();
        String s1 = intent.getExtras().getString("s1");
        String s2 = intent.getExtras().getString("s2");
        c = intent.getExtras().getInt("c");
        if(Integer.parseInt(s2) < 0){
            textView.setText( s1 + "+(" + s2 + ")=" + c);
        } else {

            textView.setText(s1 + "+" + s2 + "=" + c);
        }
    }
}